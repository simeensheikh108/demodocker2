module.exports = function(server) {
	server.disable('x-powered-by');
}
